<?php
// Haal de gevens op uit de URL en stop deze in een variabele
$pouleID = $_GET['poule_id'];
$pouleName = $_GET['pouleName'];

// Maak een variabele voor de titel
$title = "Poule | Afgerond detials";

// Voeg de header toe aan de pagina
include_once("header.php");
?>

<section>
    <h1>Details over <?php echo $pouleName; ?> poule</h1>
    <?php
    // Maak een query om de gegevens van de userpoules op te halen, sorteer deze van hoog naar laag en gebruik de kolom points hiervoor
    $getPouleInfo = mysqli_query($mysqli, "SELECT * FROM `userPoules` WHERE `poule_id` = '$pouleID' ORDER BY `points` DESC");

    // Is er een rij gevonden
    if (mysqli_num_rows($getPouleInfo) > 0) { ?>
        <table class="table table-bordered text-center w-75 mx-auto">
            <thead>
                <th>#</th>
                <th>Gebruikersnaam</th>
                <th>Punten</th>
            </thead>
            <tbody>
            <?php
                // Zet een variabele om de positie van de gebruiker te bepalen
                $positie = 1;
                // Loop door de rij heen, doe dit één rij per keer
                while ($pouleFinishedInfoRow = mysqli_fetch_array($getPouleInfo) ) {
                    // Zet de gebruikers ID in een variabele
                    $userIDPoule = $pouleFinishedInfoRow['user_id'];

                    // Maak een query om de gegevens van de gebruiker uit te lezen
                    $getUserInfoQuery = mysqli_query($mysqli, "SELECT * FROM `user` WHERE `user_id` = '$userIDPoule'");

                    // Is er een rij gevonden
                    if (mysqli_num_rows($getUserInfoQuery) > 0) {
                        // Loop door deze rij heen
                        while($userInfoRow = mysqli_fetch_array($getUserInfoQuery)) { ?>
                            <!-- Is de positie van de gebruiker één laat dan een groene achetgrond kleur zien -->
                            <tr <?php if ($positie == 1) { echo "class='bg-success text-white'"; } elseif ($userIDPoule == $user_id) { echo "class='bg-warning'"; } ?> >
                                <th><?php echo $positie; ?></th>
                                <td><?php echo $userInfoRow['username']; ?></td>
                                <td>
                                    <?php
                                    // Heeft de gebruiker een punt gehaald
                                    if (!is_null($pouleFinishedInfoRow['points'])) {
                                        // Laat de punten zien
                                        echo $pouleFinishedInfoRow['points'];
                                    }
                                    // De gebruiker heeft geen punten gehaald
                                    else {
                                        // Laat de tekst zien
                                        echo "N.V.T";
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php }
                    }
                    ?>
                <?php $positie++; } ?>
            </tbody>
        </table>
    <?php }
    // Geen rij gevonden
    else {
        // Geef de gebruiker een error
        echo "Er ging iets fout, probeer het opnieuw.";
    } ?>

    <a href="poule.php">Ga terug</a>
</section>

<?php
// Voeg de footer toe aan de pagina
include_once ('footer.php');
?>