<?php
// Maak een variabele voor de titel
$title = 'Poule';

// Voeg de header toe aan de pagina
include_once('header.php');
?>

<section>
    <h1>Welkom op de poule site</h1>
    <p>Deze site is bedoeld voor voetbalfanaten welke altijd voorspellen welk team er gaat winnen.</p>
</section>

<?php
// Voeg de footer toe aan de applicatie
include_once ('footer.php');
?>