<?php

// Gegevens van de database

// De hostname van de database
$db_hostname = 'localhost';

// De gebruikersnaam van de database
$db_username = '81746_exam';

// Het wachtwoord van de database
$db_password = 'q80zd7A^';

// De databasenaam
$db_database = '81746_examen';

// Connectie met de database
$mysqli = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);

// Is er geen connectie mogelijk, verkeerde gegevens?
if(!$mysqli) {
    // Geef een error aan de gebruiker
    echo "Fout: geen connecte met database";
}

?>