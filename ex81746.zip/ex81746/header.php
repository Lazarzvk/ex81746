<?php
// Zet de tijdzone
date_default_timezone_set('Europe/Amsterdam');

// Start de sessie
session_start();

// Voeg het bestand config.inc.php toe, gebruik require_once om het bestand maar één keer toe te voegen
require_once 'config.inc.php';

// Voeg het bestand session.php toe, gebruik require_once om het bestand maar één keer toe te voegen
require_once  'session.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="index.php">Poule</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <?php
                // Is de gebruiker niet ingelogd
                if(!$_SESSION['login']) { // Voeg het linkje toe aan het navigatiemenu ?>
                    <li class="nav-item">
                        <a class="nav-link text-success" href="login.php">Inloggen</a>
                    </li>
                <?php }
                ?>
                <?php
                // Is de gebruiker ingelogd
                if($_SESSION['login']) {
                    // Is de rank van de gebruiker kleiner dan één(gebruiker)
                    if ($_SESSION['rank'] < 1) { // Voeg het linkje toe aan het navigatiemenu ?>
                        <li class="nav-item">
                            <a class="nav-link" href="poule.php">Jouw poules</a>
                        </li>
                    <?php }
                    // Is de rank van de gebruiker gelijk aan 1(administator)
                    if ($_SESSION['rank'] == 1) { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="adminPouleDetail.php">Jouw poules beheren</a>
                        </li>
                    <?php }
                    // is de rank van de gebruiker groter dan of gelijk aan één(administrator)
                    if ($_SESSION['rank'] >= 1) { // Voeg het linkje toe aan het navigatiemenu ?>
                        <li class="nav-item">
                            <a class="nav-link" href="createPoule.php">Poule aanmaken</a>
                        </li>
                    <?php
                    // Is de rank van de gebruiker groter dan of gelijk aan twee(administrator van de applicatie)
                    if ($_SESSION['rank'] >= 2) { // Voeg het linkje toe aan het navigatiemenu ?>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">Beheer gebruikers</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="addResult.php">Uitslag invoeren</a>
                        </li>
                    <?php }
                    } // Voeg het linkje toe aan het navigatiemenu?>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="logout.php">Uitloggen</a>
                        </li>
                    <?php
                }
                ?>
            </ul>
        </div>
    </nav>