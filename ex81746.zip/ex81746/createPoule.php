<?php
// Maak een variabele voor de titel

// Voeg de header toe aan de pagina
$title = 'Poule | Poule aanmaken';
include_once('header.php');

// Functie om een string te maken van willekeurige letters en nummers
function generateRandomString($number) {
    // Maak een variabele met de karakters
    $data = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";

    // Mak een lege variabele aan, deze wordt gebruikt om een reactie te sturen aan de gebruiker
    $string = "";

    // Maak een loop aan en zet een maximum
    for($a = 0; $a < $number; $a++) {
        // Voeg een karakter van $data toe aan $string
        $string .= substr(str_shuffle($data), 0, 1);
    }
    // Geef een reactie aan de gebruiker
    return $string;
}

// Is er op submit geklikt
if(isset($_POST['submit'])) {
    // Zijn alle velden ingevuld
    if (!empty($_POST['pouleName']) && $_POST['totalUsers'] > 0 &&!empty($_POST['endDate'])) {

        // Is de waarde van het veld totalUsers een getal
        if (!is_nan($_POST['totalUsers'])) {
            // Maak een variabel om de huidige datum en tijd te krijgen
            $currentDate = new DateTime();
            // Voeg één dag toe
            $currentDate->modify('+1 day');

            // Is de einddatum een "latere" datum en tijd dan de huidige datum en tijd
            if ($_POST['endDate'] > $currentDate->format("Y-m-d H:i")) {



                // Maak een variabele aan en haal de html eruit
                $pouleName = strip_tags($_POST['pouleName']);
                $totalUsers = strip_tags($_POST['totalUsers']);
                $endDate = strip_tags($_POST['endDate']);

                // mysqli_real_escape_string voorkomt dat er een query wordt gedaan als deze is ingevuld
                $pouleName = mysqli_real_escape_string($mysqli, $pouleName);
                $endDate = mysqli_real_escape_string($mysqli, $endDate);

                // Maak een query om de poule toe te voegen aan de database
                $addPouleQuery = mysqli_query($mysqli, "INSERT INTO `poule` (`pouleName`, `createdBy`) VALUES ( '$pouleName', '$user_id' )");

                // Sla de unieke ID op in eeen variabele, mysqli_insert_id pakt de ID van de laatste query
                $pouleID = mysqli_insert_id($mysqli);

                // Is het toevoegen van de poule gelukt
                if ($addPouleQuery > 0) {

                    // Maak een loop en zet er een maximum op van het aantal gebruikers
                    for ($currentUser = 0; $currentUser < $totalUsers; $currentUser++) {
                        // Maak een variabele en vul deze met de "uitkomst" van ded function generateRandomString
                        $password = generateRandomString(20);
                        $username = generateRandomString(10);

                        // Encrypt het wachtwoord
                        $encryptedPass = sha1($password);

                        // Maak een query om de gebruiker toe te voegen
                        $query = mysqli_query($mysqli, "INSERT INTO `user` (`username`, `password`, `userRank`) VALUES ('$username', '$encryptedPass', '0');");

                        // Sla de unieke ID op in eeen variabele, mysqli_insert_id pakt de ID van de laatste query
                        $currentUserId = mysqli_insert_id($mysqli);

                        // Is het toevoegen van de gebruiker gelukt
                        if ($query > 0) {
                            // Maak een query aan om de gebruikers id en poule id in de database op te slaan
                            $addUserToPouleQuery = mysqli_query($mysqli, "INSERT INTO `userPoules` (`poule_id`, `user_id`, `placeUpdateTimer`) VALUES ( '$pouleID', '$currentUserId', '$endDate' )");

                            // Is het opslaan gelukt
                            if ($addUserToPouleQuery > 0) {
                                // Maak een variabele om de gebruikersnaam en wachtwoord aan de gebruiker te tonen
                                $succes .= "<p>Het wachtwoord van " . $username . " is: " . $password . "</p>";
                            }
                            // Opslaan is niet geulkt
                            else {
                                // Geef een error
                                $error = "Er ging iets fout, probeer het opnieuw.";
                            }
                        }
                        // Het toevoegen van de gebruiker is niet gelukt
                        else {
                            // Geef een error aan de gebruiker
                            $error = "Er ging iets fout, probeer het opnieuw.";
                        }
                    }
                }
                // Het toevegen van de poule is niet gelukt
                else {
                    // Geef de gevruiker een error
                    $error = "Kon de poule " . $pouleName . " niet aanmaken.";
                }

            }
            // De datum klopt niet
            else {
                // Geef een error aan de gebruiker
                $error = "Ongeldige datum gekozen, de datum moet minimaal één dag na vandaag zijn.";
            }
        }
        // De waarde is geen getal
        else {
            // Geef een error aan de gebruiker
            $error = "Het veld gebruikers moet een getal zijn.";
        }
    }
    // Niet alle velden zijn ingevuld of het veld totalUsers is geen getal
    else {
        // Geef een error aan de gebruiker
        $error = "Vul alle velden in.";
    }
}
?>

<section>
    <h1>Voeg een poule toe</h1>
    <small class="text-danger">Let op: de gebruikersnaam en wachtwoord wordt automatisch gegenereerd! Sla deze op.</small>

    <form method="POST">
        <div class="form-group">
            <label>Poule naam:</label>
            <input type="text" name="pouleName" class="form-control">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Aantal gebruikers:</label>
            <input type="number" name="totalUsers" class="form-control">
        </div>
        <div class="form-group">
            <label>Datum tot einde inschrijving aanpassen.</label>
            <input type="datetime-local" name="endDate" class="form-control" data-provide="datepicker">
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="Voeg toe">
        <?php
        // Is de variabele $error niet leeg, er is iets fout gegaan bij het aanmaken van de poule/gebruiker(s)
        if(!empty($error)) {
            // Laat de error zien met de variabelenaam $error
            echo "<span class='text-danger'>" . $error . "</span>";
        }
        // Laat het bericht zien met de variabelenaam $succes
        echo $succes;
        ?>
    </form>
</section>

<?php
// Voeg de footer toe aan de applicatie
include_once ('footer.php');
?>