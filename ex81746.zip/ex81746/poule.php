<?php
// Maak een variabele voor de titel
$title = "Poule | huidige/afgeronde poules";

// Voeg de header toe aan de pagina
include_once("header.php");

// Maak de query om de gegevens van een specifieke poule uit te lezen
$getUserPoules = mysqli_query($mysqli, "SELECT * FROM `poule` WHERE `poule`.`poule_id` = (SELECT `userPoules`.`poule_id` FROM `userPoules` WHERE `userPoules`.`user_id` = '$user_id')"); ?>

<section>
    <?php
    // Is er een rij gevonden
    if (mysqli_num_rows($getUserPoules) > 0) {
        // Loop door de rij heen
        while ($row = mysqli_fetch_array($getUserPoules)) {
            // Is de resultsConfirmed gelijk aan null, dus nog mee bezig
            if ($row['resultsConfirmed'] == 0) { ?>
                <h1>Poules waaraan je meedoet.</h1>
                <table class="table table-bordered text-center w-75 mx-auto">
                    <thead>
                        <tr>
                            <th>Poule ID</th>
                            <th>Naam</th>
                            <th>Tijd</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th><?php echo $row['poule_id']; ?></th>
                            <td><?php echo $row['pouleName']; ?></td>
                            <td><a class="text-info" href="pouleDetail.php?poule_id=<?php echo $row['poule_id'] . "&pouleName=" . $row['pouleName']; // Voeg de variabele toe aan de URL ?>">Details</a></td>
                        </tr>
                    </tbody>
                </table>
            <?php }
            // De poule is afgelopen, de resultaten zijn binnen
            else {  // Laat het volgende zien?>
                <h1>De uitslag van een of meerdere poules is binnen</h1>
                <table class="table table-bordered text-center w-75 mx-auto">
                    <thead>
                        <tr>
                            <th>Poule ID</th>
                            <th>Naam</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <th><?php echo $row['poule_id']; ?></th>
                        <td><?php echo $row['pouleName']; ?></td>
                        <td><a class="text-info" href="pouleFinished.php?poule_id=<?php echo $row['poule_id'] . "&pouleName=" . $row['pouleName']; // Voeg de variabele toe aan de URL ?>">Details</a></td>
                    </tr>
                    </tbody>
                </table>
            <?php } ?>
        <?php } ?>
    <?php }
    // Is er geen rij gevonden
    else {
        // Geef een error aan de gebruiker
        echo "Je doet nog niet mee aan een poule";
    }
    ?>
</section>

<?php
// Voeg de footer toe aan de applicatie
include_once ('footer.php');
?>