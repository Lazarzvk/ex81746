<?php
// Start de sessie
session_start() ;

// Vernietig de sessie
session_destroy() ;

// Stuur de gebruiker naar de index.php pagina
header("Location: index.php");
?>