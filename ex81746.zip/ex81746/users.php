<?php
// Maak een variabele voor de titel
$title = "Poule | Gebruikers beheerpagina";

// Voeg de header toe aan de pagina
include_once("header.php");

// Functie om een string te maken van willekeurige letters en nummers
function generateRandomString($number) {
    // Maak een variabele met de karakters
    $data = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";

    // Mak een lege variabele aan, deze wordt gebruikt om een reactie te sturen aan de gebruiker
    $string = "";

    // Maak een loop aan en zet een maximum
    for($a = 0; $a < $number; $a++) {
        // Voeg een karakter van $data toe aan $string
        $string .= substr(str_shuffle($data), 0, 1);
    }
    // Geef een reactie aan de gebruiker
    return $string;
}

// is er op addPouleAdmin geklikt
if (isset($_POST['addPouleAdmin'])) {
    // Is het veld ingevuld
    if (!empty($_POST['usernamePouleAdmin'])) {
        // Zet de waarde van het veld in een variabele en haal de html eruit
        $username = strip_tags($_POST['usernamePouleAdmin']);

        // mysqli_real_escape_string voorkomt dat er een query wordt gedaan als deze is ingevuld
        $username = mysqli_real_escape_string($mysqli, $username);

        // Maak een variabele en vul deze met de "uitkomst" van ded function generateRandomString
        $password = generateRandomString(20);

        // Encrypt het wachtwoord
        $encryptedPassword = sha1($password);

        // Maak een query om de gebruiker toe te voegen
        $addAdminAccountQuery = mysqli_query($mysqli, "INSERT INTO `user` (`username`, `password`, `userRank`) VALUES ('$username', '$encryptedPassword', '1')");

        // Is het toevoegen van de gebruiker gelukt
        if ($addAdminAccountQuery > 0) {
            // Maak een variabele om de gebruikersnaam en wachtwoord aan de gebruiker te tonen
            $succesAddAdmin = "De gebruiker " . $username . " is toegevoegd en het gegenereerde wachtwoord is: " . $password;
        }
        // Toe voegen is niet gelukt
        else {
            // Geef de gebruiker een error
            $errorAddAdmin = "Er ging iets fout, probeer het opnieuw.";
        }
    }
    // Veld is niet ingevuld
    else {
        // Geef de gebruiker een error
        $errorAddAdmin = "Vul alle velden in.";
    }
}
?>
<section>
    <h1>Administrator toevoegen</h1>
    <small class="text-danger">Let op: deze administrator kan gebruikers toevoegen, een poule aanmaken en gebruikers verwijderen van een poule.<br>Het wachtwoord wordt automatisch gegenereerd, sla deze dus op.</small>
    <form method="POST">
        <div class="form-group">
            <label>Gebruikersnaam</label>
            <input type="text" name="usernamePouleAdmin" class="form-control">
        </div>
        <input type="submit" name="addPouleAdmin" class="btn btn-primary" value="Administrator toevoegen">
    </form>
    <?php echo $succesAddAdmin; echo $errorAddAdmin; ?>

    <hr>
    <?php
    // Maak query om alle gebruikers te krijgen met een rank lager dan 2
    $getAllUsersQuery = mysqli_query($mysqli, "SELECT * FROM `user` WHERE `userRank` < '2' ORDER BY `user_id` ASC");
    // Als er rijen zijn gevonden
    if (mysqli_num_rows($getAllUsersQuery) > 0) { ?>
        <h2>Alle gebruikers</h2>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Gebruikersnaam</th>
                    <th>Rank/positie</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Loop door de rijen één voor één
                    while ($usersRow = mysqli_fetch_array($getAllUsersQuery)) { ?>
                    <tr>
                        <td><?php echo $usersRow['user_id']; ?></td>
                        <td><?php echo $usersRow['username']; ?></td>
                        <?php
                        // Als de userRank gelijk is aan 0
                        if ($usersRow['userRank'] == 0) {
                            // Laat dit zien
                            echo "<td>Gebruiker</td>";
                        }
                        // userRank niet gelijk aan 0
                        else {
                            // Laat dit zien
                            echo "<td>Administator</td>";
                        }
                        ?>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php }
    // Geen rijen gevonden
    else {
        // Geef een error aan de gebruiker
        echo "Er zijn geen gebruikers";
    }
    ?>
</section>
<?php
// Voeg de footer toe aan de pagina
include_once ('footer.php');
?>