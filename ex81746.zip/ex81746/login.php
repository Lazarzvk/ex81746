<?php
// Maak een variabele voor de titel
$title = 'Poule | inloggen';
// Voeg de header toe aan de pagina
include_once('header.php');

// Check of er op submit is gedrukt
if(isset($_POST['submit'])) {
    // Zijn de velden ingevuld
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        // Maak een variabel voor de gebruikersnaam en wachtwoord en haal de html eruit
        $username = strip_tags($_POST['username']);
        $password = strip_tags($_POST['password']);

        // mysqli_real_escape_string voorkomt dat er een query wordt gedaan als deze is ingevuld
        $username = mysqli_real_escape_string($mysqli, $username);
        $password = mysqli_real_escape_string($mysqli, $password);

        // Encrypt het wachtwoord
        $password = sha1($password);

        // Query om te kijken of er een gebruiker is met deze gebruikersnaam en wachtwoord
        $query = mysqli_query($mysqli, "SELECT * FROM `user` WHERE username = '$username' AND password = '$password'");

        // Is er een gebruiker gevonden met deze gebruikersnaam en wachtwoord
        if(mysqli_num_rows($query) > 0) {
            // Voeg een variabele toe aan de sessie
            $_SESSION['login'] = 'login';
            // Loop door de rij van de gebruiker
            while ($row = mysqli_fetch_array($query)) {
                // Voeg de userRank toe aan de sessie
                $_SESSION['rank'] = $row['userRank'];
                // Voeg de user_id toe aan de sessie
                $_SESSION['user_id'] = $row['user_id'];
            }
            // Stuur de gebruiker naar de index.php pagina
            header("Location: index.php");
        }
        // Geen gebruiker gevonden, geef een error
        else {
            $error = "Verkeerde login.";
        }
    }
    // Velden niet ingevuld, geef een error
    else {
        $error = "Vul alle velden in.";
    }
}
?>
<section>
    <form method="POST">
        <div class="form-group">
            <label>Gebruikersnaam:</label>
            <input type="text" name="username" class="form-control">
        </div>
        <div class="form-group">
            <label>Wachtwoord:</label>
            <input type="password" name="password" class="form-control">
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="Login">
        <?php
        if(!empty($error)) {
            echo "<span class='text-danger'>" . $error . "</span>";
        }
        ?>
    </form>
</section>

<?php
// Voeg de footer toe aan de applicatie
include_once ('footer.php');
?>