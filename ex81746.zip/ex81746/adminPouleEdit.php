<?php
// Haal de gevens op uit de URL en stop deze in een variabele
$pouleID = $_GET['poule_id'];
$pouleName = $_GET['pouleName'];

// Maak een variabele voor de titel
$title = 'Poule | Poule bewerken';

// Voeg de header toe aan de pagina
include_once('header.php');

?>

<section>
    <h1><?php echo $pouleName; ?> bewerken</h1>
    <?php
    // Maak query om de gebruikers ID's te krijgen bij deze poule
    $getUserOfPouleQuery = mysqli_query($mysqli, "SELECT * FROM `userPoules` WHERE `poule_id` = '$pouleID'");
    // Is er een rij gevonden
    if (mysqli_num_rows($getUserOfPouleQuery) > 0) { ?>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Gebruikersnaam</th>
                    <th></th>
                </tr>
            </thead>
            <?php
            // Loop door de rijen heen
            while ($getUsersRow = mysqli_fetch_array($getUserOfPouleQuery)) {
                // Zet de gebruikers ID in een variabel
                $userID = $getUsersRow['user_id'];

                // Maak een query om de gebruikersinformatie te krijgen
                $getuserInfoQuery = mysqli_query($mysqli, "SELECT * FROM `user` WHERE `user_id` = '$userID'");

                // Is er een rij gevonden
                if (mysqli_num_rows($getuserInfoQuery) > 0) {
                    // Loop door de rijen heen
                    while ($userInfoRow = mysqli_fetch_array($getuserInfoQuery)) { ?>
                        <tr>
                            <td><?php echo $userInfoRow['user_id']; ?></td>
                            <td><?php echo $userInfoRow['username']; ?></td>
                            <td><a class="text-danger" href="adminDeleteUser.php?user_id=<?php echo $userInfoRow['user_id'] . "&username=" . $userInfoRow['username']; ?>">Verwijder gebruiker</a></td>
                        </tr>
                   <?php }
                }
                else {
                    echo "N.V.T";
                }
            } ?>
        </table>
    <?php }
    // Geen rij gevonden
    else {
        // Geef een error aan de gebruiker
        echo "Geen gebruikers gevonden";
    }
    ?>
</section>

<?php
// Voeg de footer toe aan de applicatie
include_once ('footer.php');
?>