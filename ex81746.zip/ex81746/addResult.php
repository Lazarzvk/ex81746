<?php
// Maak een variabele voor de titel
$title = "Poule | Uitslag invoeren";

// Voeg de header toe aan de pagina
include_once("header.php");

// Functie om de tekst bij het juiste veld te zetten
function getEndingPlaceText($number) {
    switch ($number) {
        // Is de $number gelijk aan 1
        case 1:
            // Geef een reactie
            return "Eerste plek";
            break;
        // Is de $number gelijk aan 2
        case 2:
            // Geef een reactie
            return "Tweede plek";
            break;
        // Is de $number gelijk aan 3
        case 3:
            // Geef een reactie
            return "Derde plek";
            break;
        // Is de $number gelijk aan 4
        case 4:
            // Geef een reactie
            return "Vierde plek";
            break;
    }
}

// Is er op submit geklikt
if (isset($_POST['submit'])) {

    // Maak een array aan
    $allPlaces = array();

    // Maak variabele voor de gekozen eindstand
    $place1 = strip_tags($_POST['place1']);
    $place2 = strip_tags($_POST['place2']);
    $place3 = strip_tags($_POST['place3']);
    $place4 = strip_tags($_POST['place4']);

    // mysqli_real_escape_string voorkomt dat er een query wordt gedaan als deze is ingevuld
    $place1 = mysqli_real_escape_string($mysqli, $place1);
    $place2 = mysqli_real_escape_string($mysqli, $place2);
    $place3 = mysqli_real_escape_string($mysqli, $place3);
    $place4 = mysqli_real_escape_string($mysqli, $place4);

    // Voeg de variabele toe aan de array
    array_push($allPlaces, $place1, $place2, $place3, $place4);

    // Check of de array uit vier bestaat, array_uique haalt een dubbele item uit de array
    if (count(array_unique($allPlaces)) == 4) {

        // Maak de query aan om de eindstand in de database op te slaan
        $setFinalResultsQuery = mysqli_query($mysqli, "INSERT INTO `finalResults` (`firstPlace`, `secondPlace`, `thirdPlace`, `fourthPlace`) VALUES ('$place1', '$place2', '$place3', '$place4');");

        // Sla de unieke ID op in eeen variabele, mysqli_insert_id pakt de ID van de laatste query
        $resultsID = mysqli_insert_id($mysqli);

        // Is het toevoegen gelukt
        if ($setFinalResultsQuery > 0) {
            // Maak een query om de poule gegevens op te halen
            $setPouleResultQuery = mysqli_query($mysqli, "SELECT * FROM `poule`");

            // Is er een rij gevonden
            if (mysqli_num_rows($setPouleResultQuery) > 0) {
                // Loop door de query om de gegevens van de poule op te halen
                while ($pouleRow = mysqli_fetch_array($setPouleResultQuery)) {
                    // Zet de poule_id in een variabele
                    $pouleID = $pouleRow['poule_id'];

                    // Zet de resultsConfirmed in een variabele
                    $pouleResultsConfirmed = $pouleRow['resultsConfirmed'];

                    // Is de resultsConfirmed gelijk aan nul, de poule is niet afgerond
                    if ($pouleResultsConfirmed == 0) {
                        // Maak een query om de result toe te voegen aan de poule
                        $setResultsConfirmedQuery = mysqli_query($mysqli, "UPDATE `poule` SET `resultsConfirmed` = '$resultsID' WHERE `poule_id` = '$pouleID'");

                        // Is het updaten gelukt
                        if ($setResultsConfirmedQuery > 0) {
                            // Maak een query aan om de gebruikers uit de tabel "userPoules" te lezen
                            $getUsersQuery = mysqli_query($mysqli, "SELECT * FROM `userPoules`");

                            // Is er een rij gevonden
                            if (mysqli_num_rows($getUsersQuery) > 0 ) {
                                // Maak een query aan om de gebruikers uit de tabel "userPoules" te lezen
                                $getUsersQuery = mysqli_query($mysqli, "SELECT * FROM `userPoules`");

                                // Is er een rij gevonden
                                if (mysqli_num_rows($getUsersQuery) > 0 ) {
                                    // Maak een variabele
                                    $index = 1;

                                    // Loop door de rij heen, doe die één voor één
                                    while ($getUsersRows = mysqli_fetch_array($getUsersQuery)) {
                                        // Maak een variabele om de punten in op te slaan
                                        $userPoints = $getUsersRows['points'];

                                        if (!is_null($userPoints)) {
                                            $index ++;
                                        }
                                        else {
                                            // Maak een query om de punten toe te voegen
                                            $setUserPointsQuery = mysqli_query($mysqli, "UPDATE `userPoules` SET `points` = '$index' WHERE `userPoules`.`userPoules_id` = '$index' AND `userPoules`.`points` = '0'");

                                            // Is het toe voegen van de punten gelukt
                                            if ($setUserPointsQuery > 0) {
                                                // Geef een bericht aan de gebruiker
                                                $succesAddResults = "Uitslag is ingevoerd.";
                                            }
                                        }
                                        $index++;
                                    }
                                }
                            }
                        }
                        // Is het updaten niet gelukt
                        else {
                            // Geef een error aan de gebruiker
                            $errorAddResults = "Er ging iets fout, probeer het opnieuw.";
                        }
                    }
                }
            }
        }
        // Is het toevoegen niet gelukt, geef een error
        else {
            $errorAddResults = "Er ging iets fout, probeer het opnieuw." ;
        }
    }
    // is een land meer dan één keer gekozen, geef een error
    else {
        $errorAddResults = "Een land mag maar één keer worden gekozen";
    }
}
?>
<section>
    <h1>Uitslag invoeren</h1>
    <?php echo $succesAddResults; echo $errorAddResults; ?>
    <form method="POST">
        <?php
        // Maak een loop om vier keer een invulveld toe te voegen
        for($i = 1; $i < 5; $i++) { ?>
        <div class="form-group">
            <label><?php echo getEndingPlaceText($i); ?></label>
            <select name="place<?php echo $i; ?>" class="form-control">
                <?php
                // Query om alle landen op te halen
                $getCountriesQuery = mysqli_query($mysqli, "SELECT * FROM `landen`");

                // Is er een rij gevonden
                if (mysqli_num_rows($getCountriesQuery) > 0) {
                    // Loop door de resultaten van de query
                    while ($countryRow = mysqli_fetch_array($getCountriesQuery)) {
                        // Voeg het land toe aan het invulveld
                        echo "<option value='" . $countryRow['country_id'] ."'>" . $countryRow['countryName'] . "</option>";
                    }
                }
                // Geen rij gevonden
                else {
                    // Geef een error aan de gebruiker
                    echo "Er ging iets fout, probeer het opnieuw.<br>" . var_dump($getCountriesQuery);
                }
                ?>
            </select>
        </div>
        <?php } ?>
        <input type="submit" name="submit" class="btn btn-primary" value="Uitslag versturen">
    </form>
</section>

<?php
// Voeg de footer toe aan de applicatie
include_once ('footer.php');
?>

<!--

Test accounts

user: LCoGLLCpjE | 1
pass: JrKu0s09mmKJFqblXDCx

1. Duitsland
2. Italië
3. Rusland
4. Frankrijk

user: hamyLnH9C5 | 1
pass: 9SQEuPtZ01zdbFcT2fo5

1. Duitsland
2. Rusland
3. Engeland
4. Nederland

user: ftrLuhWml6 | 1
pass: NlyZhf2hmggrSMBl7DtJ

1. Rusland
2. Duitsland
3. Oekraine
4. Zwitserland
-->