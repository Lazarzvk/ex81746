<?php
// Haal de gevens op uit de URL en stop deze in een variabele
$pouleID = $_GET['poule_id'];
$pouleName = $_GET['pouleName'];

// Maak een variabele voor de titel
$title = "Poule | details " . $pouleName;

// Voeg de header toe aan de pagina
include_once("header.php");

// Maak een query op de gegevens van de gebruiker uit te lezen
$getuserPoulesQuery = mysqli_query($mysqli, "SELECT * FROM `userPoules` WHERE `user_id` = '$user_id' AND `poule_id` = '$pouleID'"); ?>

<section>
    <?php
    // Is er op submit geklikt
    if (isset($_POST['submit'])) {

        // Maak een array
        $allPlaces = array();

        // Maak een variabele voor de ingevulde waardes
        $place1 = strip_tags($_POST['place1']);
        $place2 = strip_tags($_POST['place2']);
        $place3 = strip_tags($_POST['place3']);
        $place4 = strip_tags($_POST['place4']);

        // mysqli_real_escape_string voorkomt dat er een query wordt gedaan als deze is ingevuld
        $place1 = mysqli_real_escape_string($mysqli, $place1);
        $place2 = mysqli_real_escape_string($mysqli, $place2);
        $place3 = mysqli_real_escape_string($mysqli, $place3);
        $place4 = mysqli_real_escape_string($mysqli, $place4);

        // Voeg de variabele toe aan de array
        array_push($allPlaces, $place1, $place2, $place3, $place4);

        // Check of de array uit vier bestaat, array_uique haalt een dubbele item uit de array
        if (count(array_unique($allPlaces)) == 4) {
            // Is er een rij gevonden
            if (mysqli_num_rows($getuserPoulesQuery) > 0) {
                // Loop door de rij
                while($userPoulesRow = mysqli_fetch_array($getuserPoulesQuery)) {
                    // Zet de userPoules ID in een variabele
                    $userPoulesID = $userPoulesRow['userPoules_id'];

                    // Maak een query om de eindstand te updaten
                    $setListedCountries = mysqli_query($mysqli, "UPDATE `userPoules` SET `firstPlace_countryID` = '$place1', `secondPlace_countryID` = '$place2', `thirdPlace_countryID` = '$place3', `fourthPlace_countryID` = '$place4' WHERE `userPoules`.`userPoules_id` = '$userPoulesID'");

                    // Is het updaten gelukt
                    if ($setListedCountries > 0) {
                        // Geef de gebruiker een bericht
                        echo "Je wijzigingen zijn toegepast.";
                    }
                    // Het updaten is niet gelukt
                    else {
                        // Geef een error aan de gebruiker
                        echo "Er ging iets fout, probeer het opnieuw." ;
                    }
                }
            }
            // Geen rij gevonden
            else {
                // Geef de gebruiker een error
                echo "Er ging iets fout, probeer het opnieuw";
            }
        }
        // is een land meer dan één keer gekozen
        else {
            // Geef een error aan de gebruiker
            echo "Een land mag maar één keer worden gekozen";
        }
    }

    // Zijn er rijen gevonden
    if (mysqli_num_rows($getuserPoulesQuery) > 0) {
        // Loop door de rij één voor één
        while ($pouleDetailsRow = mysqli_fetch_array($getuserPoulesQuery) ) { ?>
            <h1>Details van <?php echo $pouleName; ?>:</h1>
            <?php
            // Zet de einddatum in een variabele
            $endDate = $pouleDetailsRow['placeUpdateTimer'];

            // Maak een variabel om de huidige datum en tijd te krijgen
            $currentDate = new DateTime();

            // Is de einddatum om de eindstand te wijzigen eerder dan nu
            if ($currentDate->format("Y-m-d H:i") > $endDate) { ?>
                <h3>Je kunt de eindstand niet meer wijzigen.</h3>
            <?php }
            // Is het nog niet de einddatum
            else {
            ?>
                <small class="text-danger">Je kunt tot
                    <?php
                    // Zet de einddatum in een variabele
                    $endDate = $pouleDetailsRow['placeUpdateTimer'];
                    // Formatteer de datum
                    echo $endDate = date("d-m-Y H:i", strtotime($endDate)) . " ";
                    ?>
                    de eindstand wijzigen.<br>
                    Let op: Een land mag maar één keer worden gekozen.
                </small>
                <table class="table table-bordered text-center">
                <thead>
                    <th>Land op de eerste plek</th>
                    <th>Land op de tweede plek</th>
                    <th>Land op de derde plek</th>
                    <th>Land op de vierde plek</th>
                    <th></th>
                </thead>
                <tbody>
                    <tr>
                        <form method="POST">
                            <?php
                            // Maak een loop met een maximum van 5
                            for($i = 1; $i < 5; $i++) { ?>
                                <td>
                                    <select name="place<?php echo $i; ?>">
                                        <?php
                                        // Maak query om de landen op te halen
                                        $getCountriesQuery = mysqli_query($mysqli, "SELECT * FROM `landen`");

                                        // Is er een rij gevonden
                                        if (mysqli_num_rows($getCountriesQuery) > 0) {
                                            // Loop door een enkele rij
                                            while ($countryRow = mysqli_fetch_array($getCountriesQuery)) {
                                                // Laat de huidge rij zien
                                                echo "<option value='" . $countryRow['country_id'] ."'>" . $countryRow['countryName'] . "</option>";
                                            }
                                        }
                                        // Geen rij
                                        else {
                                            // Geef een error aan de gebruiker
                                            echo "Er ging iets fout, probeer het opnieuw.<br>" . var_dump($getCountriesQuery);
                                        }
                                        ?>
                                    </select>
                                </td>
                            <?php }
                            ?>
                            <td><input class="btn btn-link text-success" type="submit" name="submit" value="Wijzigen"></td>
                        </form>
                    </tr>
                </tbody>
            </table>
            <?php } ?>
        <?php } ?>
    <?php }
    else {
        echo "Er ging iets fout, probeer het opnieuw.";
    } ?>

    <a href="poule.php">Ga terug</a>
</section>

<?php
// Voeg de footer toe aan de pagina
include_once ('footer.php');
?>