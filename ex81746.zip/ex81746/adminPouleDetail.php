<?php
// Maak een variabele voor de titel

// Voeg de header toe aan de pagina
$title = 'Poule | Poules beheren';
include_once('header.php');
?>

<section>
    <?php
    $getAllUsersQuery = mysqli_query($mysqli, "SELECT * FROM `poule` WHERE `createdBy` = '$user_id' ORDER BY `poule_id` ASC");
    if (mysqli_num_rows($getAllUsersQuery) > 0) { ?>
        <h2>Alle poules</h2>
        <table class="table table-bordered text-center">
            <thead>
            <tr>
                <th>ID</th>
                <th>Gebruikersnaam</th>
                <th>Details</th>
            </tr>
            </thead>
            <tbody>
            <?php while ($pouleRow = mysqli_fetch_array($getAllUsersQuery)) { ?>
                <tr>
                    <td><?php echo $pouleRow['poule_id']; ?></td>
                    <td><?php echo $pouleRow['pouleName']; ?></td>
                    <td><a class="text-info" href="adminPouleEdit.php?poule_id=<?php echo $pouleRow['poule_id'] . "&pouleName=" . $pouleRow['pouleName']; ?>">Details</a></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php }
    else {
        echo "Kon geen users vinden";
    }
    ?>
</section>

<?php
// Voeg de footer toe aan de applicatie
include_once ('footer.php');
?>