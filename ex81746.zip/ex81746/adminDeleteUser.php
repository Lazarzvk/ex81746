<?php

// Haal de gevens op uit de URL en stop deze in een variabele
$userID = $_GET['user_id'];
$username = $_GET['username'];

// Maak een variabele voor de titel
$title = 'Poule | Poule bewerken';

// Voeg de header toe aan de pagina
include_once('header.php');

// Maak query om de gebruiker te verwijderen uit tabel userPoules
$deleteUserFromuserPoules = mysqli_query($mysqli, "DELETE FROM `userPoules` WHERE `user_id` = '$userID'");

// Maak query om de gebruiker te verwijderen uit de tabel user
$deleteUserFromuser = mysqli_query($mysqli, "DELETE FROM `user` WHERE `user_id` = '$userID'");

// Is gebruiker verwijderd
if ($deleteUserFromuserPoules > 0 && $deleteUserFromuserPoules > 0) {
    // Ga terug naar de adminPouleEdit.php pagina
    header("Location: adminPouleEdit.php");
}
else {
    echo "Er ging iets fout <a href='adminPouleEdit.php'>ga terug</a>";
}
?>
